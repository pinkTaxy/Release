package hwr.stud.tamponapp;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    Button button = null;
    EditText editText = null;
    TextView textView = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button = (Button)findViewById(R.id.button3);
        textView = (TextView)findViewById(R.id.textView);
        editText = (EditText)findViewById(R.id.editText);

        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final String request = editText.getText().toString();
                AsyncTask.execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            URL tamponURL = new URL(request);
                            HttpURLConnection tamponConnection = (HttpURLConnection) tamponURL.openConnection();

                            // Response handling
                            if (tamponConnection.getResponseCode() == 200) {
                                System.out.print("Received response!");
                                InputStream in = new BufferedInputStream(tamponConnection.getInputStream());
                                System.out.print(in.toString());
                            } else {
                                System.out.print("Failed on reading response.");
                            }
                            tamponConnection.disconnect();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                textView.setText("Request " + request + " was sendt.");
            }
        });



    }

}
